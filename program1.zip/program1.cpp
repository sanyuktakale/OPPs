#include<iostream>
using namespace std;

int main()
{
	int a,i;
	cout<<"enter a number:";
	cin>>a;
	
	for(i=1;i<=10;i++)
	{
		cout<<"\t"<<a*i;
	}
}
